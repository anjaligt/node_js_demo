// Write client side JavaScript here
global.jQuery = global.$ = require('jquery');

require('bootstrap');
require('microplugin');
require('sifter');
require('selectize');

require('./select');
require('./functions');