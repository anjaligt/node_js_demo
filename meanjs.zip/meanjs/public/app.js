!(function(){
	angular.module('firstFiveApp',['ui.router','ngStorage','ngBootbox','ui.bootstrap','chart.js']);
})();

