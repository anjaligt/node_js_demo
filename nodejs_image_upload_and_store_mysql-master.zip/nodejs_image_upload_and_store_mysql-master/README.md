# nodejs_image_upload_example
This nodejs app use to upload and store image into mysql





# Create db and table
create test db and run usser.sql file to create user table.

#Run npm
Copy all files of this git repo into c:/project_folder and run below command
c:/project_folder> npm install

#Run node js application
c:/project_folder> node app.js

#Test nodejs application
open http://project_name:8080 on browser.